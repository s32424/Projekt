from tkinter import *

class GameOfLife:
    def __init__(self):
        """
            Creates necessary objects.

            Args:
                self
            Returns:
                none
            """
        self.currentIteration = 0
        self.viewingIteration = 0
        self.window = Tk()
        self.mainFrame = Frame(self.window)
        self.panelFrame = Frame(self.window)
        self.subFrames = []
        self.runButton = Button(self.panelFrame)
        self.iterButton = Button(self.panelFrame)
        self.clearButton = Button(self.panelFrame)
        self.sizeLabel = Label(self.panelFrame)
        self.delayPlusButton = Button(self.panelFrame)
        self.delayMinusButton = Button(self.panelFrame)
        self.delayLabel = Label(self.panelFrame)
        self.delay = 500
        self.sizeInfoLabel = Label(self.panelFrame)
        self.delayInfoLabel = Label(self.panelFrame)
        self.aliveList = []
        self.dedList = []
        self.buttonAliveList = []
        self.buttonDedList = []
        self.aliveInfoList = Label(self.panelFrame)
        self.dedInfoList = Label(self.panelFrame)

        self.prevButton = Button(self.panelFrame)
        self.nextButton = Button(self.panelFrame)
        self.iterationLabel = Label(self.panelFrame)

        self.board_size = 10
        self.cell_size = 100

        self.sizePlusButton = Button(self.panelFrame)
        self.sizeMinusButton = Button(self.panelFrame)

        self.window.geometry("1300x1000")
        self.window.title("Game of Life")
        self.window.resizable(False, False)

    def config(self):
        """
            Configures objects with default values and places them within the window.

            Args:
                self
            Returns:
                none
            """
        self.mainFrame.config(height=1000, width=1000, background="#696969")
        self.mainFrame.place(x=0, y=0)

        self.panelFrame.config(height=1000, width=300, background="#3b378e", borderwidth=2, relief="solid")
        self.panelFrame.place(x=1000, y=0)

        self.runButton.config(height=1, width=25, text="Run", command=self.mainLogic)
        self.runButton.place(x=50, y=100)

        self.iterButton.config(height=1, width=25, text="Next Iteration", command=self.iteration)
        self.iterButton.place(x=50, y=150)

        self.clearButton.config(height=1, width=25, text="Clear Board", command=self.clearBoard)
        self.clearButton.place(x=50, y=200)

        self.prevButton.config(height=1, width=25, text="View Previous", command=self.previousIteration)
        self.prevButton.place(x=50, y=250)

        self.nextButton.config(height=1, width=25, text="View Next", command=self.viewNextIteration)
        self.nextButton.place(x=50, y=300)

        self.iterationLabel.config(height=2, width=25, text="Iteration: 0/0", bg="#3b378e", fg="white")
        self.iterationLabel.place(x=50, y=350)

        self.sizePlusButton.config(height=1, width=7, text="+",
                                   command=lambda: self.changeBoardSize(self.board_size + 1))
        self.sizePlusButton.place(x=25, y=430)

        self.sizeMinusButton.config(height=1, width=7, text="-",
                                    command=lambda: self.changeBoardSize(self.board_size - 1))
        self.sizeMinusButton.place(x=225, y=430)

        self.sizeLabel.config(height=2, width=7, text="10x10")
        self.sizeLabel.place(x=125, y=425)

        self.sizeInfoLabel.config(height=2, width=7, text="SIZE", background="#3b378e")
        self.sizeInfoLabel.place(x=125, y=380)

        self.delayPlusButton.config(height=1, width=7, text="+",
                                   command=lambda: self.changeDelay(1))
        self.delayPlusButton.place(x=25, y=530)

        self.delayMinusButton.config(height=1, width=7, text="-",
                                    command=lambda: self.changeDelay(-1))
        self.delayMinusButton.place(x=225, y=530)

        self.delayLabel.config(height=2, width=7, text=str(self.delay) +" ms")
        self.delayLabel.place(x=125, y=525)

        self.delayInfoLabel.config(height=2, width=7, text="DELAY", background="#3b378e")
        self.delayInfoLabel.place(x=125, y=480)

        self.aliveInfoList.config(height=2, width=30, text="Alive live when X neighbours")
        self.aliveInfoList.place(x=37, y=590)
        for i in range(8):
            self.buttonAliveList.append(Button(self.panelFrame))
            self.buttonAliveList[i].config(height=1, width = 1, text= str(i+1),
                                           background="#FF0000",command=lambda i=i: self.buttonAliveChange(i+1))
            self.buttonAliveList[i].place(x=50 + (25*i),y = 630)

        self.dedInfoList.config(height=2, width=30, text="Dead revive with X neighbours")
        self.dedInfoList.place(x=37, y=690)
        for i in range(8):
            self.buttonDedList.append(Button(self.panelFrame))
            self.buttonDedList[i].config(height=1, width=1, text=str(i + 1),
                                           background="#FF0000", command=lambda i=i: self.buttonDedChange(i + 1))
            self.buttonDedList[i].place(x=50 + (25 * i), y=730)

        self.createBoard()
        self.updateNavigationButtons()

    def buttonAliveChange(self,i):
        """
            Changes which of the buttons representing X in "Alive live when X neighbours"
            are toggled on/off and recolours them accordingly.

            Args:
                'i': value representing the 'X' in "Alive live when X neighbours"
                i - 1 being the index of a button to toggle on/off.
            Returns:
                none
            """
        if i in self.aliveList:
            self.aliveList.remove(i)
            self.buttonAliveList[i-1].config(background="#FF0000")
        else:
            self.aliveList.append(i)
            self.buttonAliveList[i-1].config(background="#00FF00")

    def buttonDedChange(self,i):
        """
            Changes which of the buttons representing X in "Dead revive with X neighbours"
            are toggled on/off and recolours them accordingly.

            Args:
                'i': value representing the 'X' in "Dead revive with X neighbours"
                i - 1 being the index of a button to toggle on/off.
            Returns:
                none
            """
        if i in self.dedList:
            self.dedList.remove(i)
            self.buttonDedList[i-1].config(background="#FF0000")
        else:
            self.dedList.append(i)
            self.buttonDedList[i-1].config(background="#00FF00")

    def changeDelay(self,x):
        """
            Changes the delay between each iteration by 100ms and updates the label.

            Args:
                'x': The direction of change. Positive to increase, negative to decrease.
            Returns:
                none
            """
        if x > 0:
            self.delay += 100
        if x < 0:
            self.delay -= 100
        self.delayLabel.config(text=str(self.delay)+ " ms")

    def changeBoardSize(self, size):
        """
            Clears the board, creates a new one with a different size.

            Args:
                'size': The size of the new board.
            Returns:
                none
            """
        for frame in self.subFrames:
            frame.destroy()
        self.subFrames.clear()
        Subframe.idcounter = 0

        self.board_size = size
        self.cell_size = 1000 // size

        self.createBoard()
        self.sizeLabel.config(text=str(size) + "x" + str(size))

    def isOver(self) -> bool:
        """
            Checks whether the simulation should halt.

            Args:
                self
            Returns:
                bool: Whether the simulation should halt.
            """
        counter1 = 0
        counter2 = 0
        for frame in self.subFrames:
            if frame.state:
                counter1 += 1
            if frame.state != frame.stateHistory[self.currentIteration - 1]:
                counter2 += 1
        if counter1 == 0 or counter2 == 0:
            return True
        return False

    def createBoard(self):
        """
            Creates a square board.

            Args:
                self
            Returns:
                none
            """
        if self.board_size > 0:
            for i in range(self.board_size ** 2):
                subframe = Subframe(self.mainFrame, self.board_size, self.cell_size)
        else:
            self.board_size += 1

    def clearBoard(self):
        """
            Clears the state, future state and state history of all subframes and sets the current iteration to 0.

            Args:
                self
            Returns:
                none
            """
        for frame in self.subFrames:
            frame.state = False
            frame.futureState = False
            frame.recolour()
            frame.stateHistory.clear()
        self.currentIteration = 0
        self.viewingIteration = 0
        self.updateNavigationButtons()

    def mainLogic(self):
        """
            Recurrently invokes the next iteration every 'self.delay' milliseconds.
            Returns when 'isOver()' function returns True.

            Args:
                self
            Returns:
                none
            """
        self.iteration()
        if self.isOver():
            for frame in self.subFrames:
                frame.stateHistory.append(frame.state)
            return
        self.window.after(self.delay, lambda: self.mainLogic())

    def iteration(self, event=None):
        """
            Progresses into the next iteration of the simulation.

            Args:
                self
            Returns:
                none
            """
        if self.viewingIteration == self.currentIteration:
            self.currentIteration += 1
            self.viewingIteration = self.currentIteration

            for frame in self.subFrames:
                frame.stateHistory.append(frame.state)

            for frame in self.subFrames:
                neighbors = frame.getAliveNeighbours()

                if frame.state:  # Żyje
                    frame.futureState = neighbors in self.aliveList
                else:  # Ded
                    frame.futureState = neighbors in self.dedList

            for frame in self.subFrames:
                frame.state = frame.futureState
                frame.recolour()
        else:
            self.viewCurrentIteration()
            self.iteration()

        self.updateNavigationButtons()

    def previousIteration(self):
        """
            Displays the previous iteration.

            Args:
                self
            Returns:
                none
            """
        if self.viewingIteration > 0:
            self.viewingIteration -= 1
            self.displayIteration(self.viewingIteration)
        self.updateNavigationButtons()

    def viewNextIteration(self):
        """
            Displays the next iteration.

            Args:
                self
            Returns:
                none
            """
        if self.viewingIteration < self.currentIteration:
            self.viewingIteration += 1
            self.displayIteration(self.viewingIteration)
        self.updateNavigationButtons()

    def viewCurrentIteration(self):
        """
            Displays the current iteration.

            Args:
                self
            Returns:
                none
            """
        self.viewingIteration = self.currentIteration
        self.displayIteration(self.viewingIteration)
        self.updateNavigationButtons()

    def displayIteration(self, iteration):
        """
            Displays the given iteration.

            Args:
                'iteration': The iteration to display.
            Returns:
                none
            """
        if iteration == 0:
            for frame in self.subFrames:
                frame.state = len(frame.stateHistory) > 0 and frame.stateHistory[0] if len(
                    frame.stateHistory) > iteration else False
                frame.recolour()
        else:
            for frame in self.subFrames:
                if len(frame.stateHistory) > iteration:
                    frame.state = frame.stateHistory[iteration]
                else:
                    frame.state = False
                frame.recolour()

    def updateNavigationButtons(self):
        """
            Updates the navigation buttons based on the current iteration.

            Args:
                self
            Returns:
                none
            """
        if self.viewingIteration <= 0:
            self.prevButton.config(state="disabled")
        else:
            self.prevButton.config(state="normal")

        if self.viewingIteration >= self.currentIteration:
            self.nextButton.config(state="disabled")
        else:
            self.nextButton.config(state="normal")

        self.iterationLabel.config(text=f"Iteration: {self.viewingIteration}/{self.currentIteration}")

    def run(self):
        """
            Runs the program.

            Args:
                self
            Returns:
                none
            """
        self.config()
        self.window.mainloop()


class Subframe(Frame):
    idcounter = 0

    def __init__(self, master, board_size, cell_size):
        super().__init__(master)

        self.id = Subframe.idcounter
        self.state = False  # not lit
        self.futureState = False
        self.stateHistory = []
        self.game = game
        self.board_size = board_size
        self.cell_size = cell_size

        Subframe.idcounter += 1
        game.subFrames.append(self)

        row = self.id // self.board_size
        col = self.id % self.board_size

        board_pixel_size = self.board_size * self.cell_size
        offset_x = (1000 - board_pixel_size) // 2
        offset_y = (1000 - board_pixel_size) // 2

        self.config(height=self.cell_size, width=self.cell_size, background="#0b075e",
                    borderwidth=1, relief="solid")
        self.place(x=offset_x + col * self.cell_size, y=offset_y + row * self.cell_size)
        self.bind("<Button-1>", self.on_frame_click)

    def on_frame_click(self, event):
        """
            Changes the subframe's state upon it being clicked. Only works when viewing the current iteration.

            Args:
                self
            Returns:
                none
            """
        if self.game.viewingIteration == self.game.currentIteration:
            self.state = not self.state
            self.recolour()

    def recolour(self):
        """
            Recolours the subframe based on it's state.

            Args:
                self
            Returns:
                none
            """
        if self.state:
            self.config(background="#FFFFFF")
        else:
            self.config(background="#0b075e")

    def getAliveNeighbours(self) -> int:
        """
            Counts the number of the subframe's alive neighbours.

            Args:
                self
            Returns:
                The number of alive neighbours.
            """
        count = 0
        row = self.id // self.board_size
        col = self.id % self.board_size

        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0:
                    continue

                neighbor_row = row + dr
                neighbor_col = col + dc

                if 0 <= neighbor_row < self.board_size and 0 <= neighbor_col < self.board_size:
                    neighbor_id = neighbor_row * self.board_size + neighbor_col
                    if self.game.subFrames[neighbor_id].state:
                        count += 1

        return count

    def getState(self):
        """
            Returns the subframe's state.

            Args:
                self
            Returns:
                The subframe's state.
            """
        return self.state

if __name__ == "__main__":
    game = GameOfLife()
    game.run()